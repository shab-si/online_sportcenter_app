from django.urls import path
from . import views
#from .views import check_login


urlpatterns = [
    path('members/', views.members, name='members'),
    path('', views.login, name='login'),
    path('login/', views.login, name='login'),
    path('exitapp/', views.exitapp, name='exitapp'),
    path('protected/', views.protected_view, name='protected'),
    path('indexpage/', views.indexpage, name='indexpage'),
    path('mainpage/', views.mainpage, name='mainpage'),
    path('post/ajax/check_login/', views.check_login, name='check_login'),
    path('post/ajax/register_user/', views.register_user, name='register_user'),
    path('login/register_user/', views.register_user, name='register_user'),
    path('check_login1/', views.check_login1, name='check_login1'),
    path('coach_class/', views.coach_class, name='coach_class'),
    path('coach_detailclass/', views.coach_detailclass, name='coach_detailclass'),
    path('coachclass_givedata/', views.coachclass_givedata, name='coachclass_givedata'),
    path('give_coachclassdata_fromexcelfile/', views.give_coachclassdata_fromexcelfile, name='give_coachclassdata_fromexcelfile'),
    path('give_coachclasstimedata_fromexcelfile/', views.give_coachclasstimedata_fromexcelfile, name='give_coachclasstimedata_fromexcelfile'),
    #path('coach_detailclass/coachclassdetails/<int:classid>', views.coachclassdetails, name='coachclassdetails'),
    path('coachclassdetails/', views.coachclassdetails, name='coachclassdetails'),
    path('coachclass_tobasket/<int:classid>', views.coachclass_tobasket, name='coachclass_tobasket'),
    path('captcha/refresh/', views.refresh_captcha, name='refresh_captcha'),
    path('showclassesincards/', views.showclassesincards, name='showclassesincards'),
    path('showinfoclassesincards/', views.showinfoclassesincards, name='showinfoclassesincards'),
    path('showsports/', views.showsports, name='showsports'),
    path('sporter_choicer_class/', views.sporter_choicer_class, name='sporter_choicer_class'),
    path('sporter_choicer_class_info/', views.sporter_choicer_class_info, name='sporter_choicer_class_info'),
    path('sporterordersave/', views.sporterordersave, name='sporterordersave'),
    path('sporterordershow/', views.sporterordershow, name='sporterordershow'),
    path('bodybuildingpagecall/', views.bodybuildingpagecall, name='bodybuildingpagecall'),
    path('poolpagecall/', views.poolpagecall, name='poolpagecall'),
    path('bodybuiling_time_class/', views.bodybuiling_time_class, name='bodybuiling_time_class'),
    path('bodybuiling_timeclass_show/', views.bodybuiling_timeclass_show, name='bodybuiling_timeclass_show'),
    path('pool_time_class/', views.pool_time_class, name='pool_time_class'),
    path('pool_timeclass_show/', views.pool_timeclass_show, name='pool_timeclass_show')
    
]