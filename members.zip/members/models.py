from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class user_profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    birthdate = models.IntegerField(null=False)
    mobileno = models.CharField(max_length=11, null=False, blank=False)
    #mem_email = models.CharField(max_length=100, null=False, blank=False)
    gender = models.CharField(max_length=10, null=False, blank=False)
    def __unicode__(self):
        return self.id


class employee(models.Model):
    id = models.BigAutoField(primary_key=True)
    emp_name = models.CharField(max_length=250, unique=True, null=False, blank=False)
    emp_pass = models.CharField(max_length=250, null=False, blank=False)
    fname = models.CharField(max_length=250, null=False, blank=False)
    lname = models.CharField(max_length=250, null=False, blank=False)
    mobileno = models.CharField(max_length=11, unique=True, null=False, blank=False)
    emp_access = models.CharField(max_length=100, null=False, blank=False)
    gender = models.CharField(max_length=10, null=False, blank=False)
    def __unicode__(self):
        return self.emp_name


class Sporterchoice(models.Model):
  id = models.BigAutoField(primary_key=True)
  sporterid = models.BigIntegerField(null=True)
  coachclassid = models.IntegerField(null=True)
  coachid = models.BigIntegerField(null=True)
  sportid = models.IntegerField(null=True)
  fromdate = models.CharField(max_length=255)
  todate  = models.CharField(max_length=255)
  countsession = models.IntegerField(null=True)
  pricepersession = models.IntegerField(null=True)
  kindtakhfif = models.CharField(max_length=255)
  pricetakhfif = models.IntegerField(null=True)
  pardakhtinaghd = models.IntegerField(null=True)
  pardakhtikart = models.IntegerField(null=True)
  userid = models.IntegerField(null=True)
  createdate = models.CharField(max_length=255)
  timecreate = models.CharField(max_length=255)
  eshantionid = models.IntegerField(null=True)
  remainoldprice = models.IntegerField(null=True)
  malyat = models.IntegerField(null=True)
  darsadtakhfif = models.IntegerField(null=True)
  ghabldaryaft = models.IntegerField(null=True)
  mandehjadid = models.IntegerField(null=True)
  priceclass = models.IntegerField(null=True)
  pricesport = models.IntegerField(null=True)
  pricecard = models.IntegerField(null=True)
  cashtrans = models.CharField(max_length=255)
  coachdarsad = models.IntegerField(null=True)
  managerokchange = models.CharField(max_length=255)
  useridforchange = models.IntegerField(null=True)
  classchangedate = models.CharField(max_length=255)
  oldcountsession = models.IntegerField(null=True)
  oldpayprice = models.IntegerField(null=True)
  BasketNo = models.IntegerField(null=True)
  oldidmandeh = models.IntegerField(null=True)
  
  def __str__(self):
    return self.id


class coach(models.Model):
  id = models.BigAutoField(primary_key=True)
  fname = models.CharField(max_length=255)
  lname  = models.CharField(max_length=255)
  mobileno = models.CharField(max_length=255)
  melicode = models.CharField(max_length=255)
  empid = models.BigIntegerField(null=True)
  createdate = models.CharField(max_length=255)
  timecreate = models.CharField(max_length=255)
  
  def __str__(self):
    return self.id

class sportclass(models.Model):
  id = models.BigAutoField(primary_key=True)
  classname = models.CharField(max_length=255)
  coachid  = models.BigIntegerField(null=True)
  sessioncount = models.IntegerField(null=True)
  classprice = models.IntegerField(null=True)
  empid = models.BigIntegerField(null=True)
  createdate = models.CharField(max_length=255)
  timecreate = models.CharField(max_length=255)
  activeclass = models.CharField(max_length=1)
  
  def __str__(self):
    return self.id
  
class coachclass(models.Model):
  id = models.BigAutoField(primary_key=True)
  coachclassid = models.BigIntegerField(null=True)
  sexsession = models.CharField(max_length=255)
  sportgroupname = models.CharField(max_length=255)
  classname = models.CharField(max_length=255)
  cachname = models.CharField(max_length=255)
  freetime = models.CharField(max_length=255)
  countsession = models.IntegerField(null=True)
  sessionprice = models.BigIntegerField(null=True)
  totalclassprice = models.BigIntegerField(null=True)
  createdateprice = models.CharField(max_length=255)
  classcreatedate = models.CharField(max_length=255)
  coachid = models.BigIntegerField(null=True)
  sportid = models.BigIntegerField(null=True)
  sportgroupid = models.BigIntegerField(null=True)
  sexkindid  = models.IntegerField(null=True)
  
  def __str__(self):
    return self.id  
  
class coachclasstimes(models.Model):
  id = models.BigAutoField(primary_key=True)
  coachclassid = models.BigIntegerField(null=True)
  dayid  = models.IntegerField(null=True)
  timeid = models.BigIntegerField(null=True)
  salonid  = models.IntegerField(null=True)
  dayname = models.CharField(max_length=255)
  salonname = models.CharField(max_length=255)
  clocksport = models.CharField(max_length=255)

  def __str__(self):
    return self.id  
  

class sporterorder(models.Model):
  id = models.BigAutoField(primary_key=True)
  ## برای استخر و بدنسازی آزاد مقدار صفر وارد شود 
  coachclassid = models.BigIntegerField(null=True)
  sexsession = models.CharField(max_length=255)
  sportgroupname = models.CharField(max_length=255)
  classname = models.CharField(max_length=255)
  cachname = models.CharField(max_length=255)
  freetime = models.CharField(max_length=255)
  countsession = models.IntegerField(null=True)
  sessionprice = models.BigIntegerField(null=True)
  totalclassprice = models.BigIntegerField(null=True)
  createdateprice = models.CharField(max_length=255)
  classcreatedate = models.CharField(max_length=255)
  coachid = models.BigIntegerField(null=True)
  sportid = models.BigIntegerField(null=True)
  sportgroupid = models.BigIntegerField(null=True)
  sexkindid  = models.IntegerField(null=True)
  melicode = models.CharField(max_length=255)
  sporterfirstname = models.CharField(max_length=255)
  sporterlastname = models.CharField(max_length=255)
  sporterbankname = models.CharField(max_length=255)
  companybankname = models.CharField(max_length=255)
  sportercardno = models.CharField(max_length=255)
  sporterhesabno = models.CharField(max_length=255)
  sporterpaidprice = models.BigIntegerField(null=True)
  sporterpaiddate = models.CharField(max_length=255)  
  sporterpaidtime = models.CharField(max_length=255)
  sportermarjano = models.CharField(max_length=255)
  sporterrahgirino = models.CharField(max_length=255)
  ## 1 = chargeclass, 2 = choiceestakhr, 3 = choicebadansazi 
  sporterpaidchoice =  models.CharField(max_length=255)
  ## 0 = chargeclass, other numbers for estakhr and badansazi
  reservenumber =  models.CharField(max_length=255)
  mobileno =  models.CharField(max_length=255)

  def __str__(self):
    return self.id  
  

class sanceclass(models.Model):
  id = models.BigAutoField(primary_key=True)
  ## estakhr = 1 , badansazi = 2
  sportid = models.BigIntegerField(null=True)
  ## 1 = aghayan , 2 = banovan
  sexkindid  = models.IntegerField(null=True)
  fromtime = models.IntegerField(null=True)
  totime = models.IntegerField(null=True)
  price = models.IntegerField(null=True)
  createdate = models.CharField(max_length=255)
  sportdescipt = models.CharField(max_length=255)
  fromtimedescript = models.CharField(max_length=255)
  totimedescript = models.CharField(max_length=255)

  def __str__(self):
    return self.id  
  