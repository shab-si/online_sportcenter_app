from django.shortcuts import render, redirect
from django.db import connection
from django.http import HttpResponse
from django.template import loader, RequestContext
from django.http import HttpResponseBadRequest, JsonResponse
from django.contrib.auth import authenticate
from django.views.generic import TemplateView
import json

import pandas as pd
from django.contrib import messages
from .models import coachclass
from .models import coachclasstimes
from .models import sporterorder
from .models import sanceclass

from django.core import serializers
# پس از نصب کتابخانه جدید ایجکس
from django_ajax.decorators import ajax
from django.views.decorators.csrf import csrf_exempt

from django.contrib.auth.models import User   #table Auth_User
from django.db.models.signals import post_save
from django.dispatch import receiver

from django.utils import timezone
from datetime import datetime
from jdatetime import datetime as jdatetime
#for persian Time
import pytz
from django.utils import timezone

from .forms import myForm

from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
#from django.contrib.auth.forms import AuthenticationForm

def protected_view(request):
   return render(request, 'protected_template.html')

def mainpage(request):
  return render(request, 'mainpage.html')

def members(request):
  template = loader.get_template('index.html')
  return HttpResponse(template.render())

####################### 
def login(request):
  #template = loader.get_template('login.html')
  #return HttpResponse(template.render())
  for key in list(request.session.keys()):
    if not key.startswith("_"): # skip keys set by the django system
       del request.session[key]

  form = myForm()
  return render(request, 'login.html', {'form': form})

###########################
def exitapp(request):
    for key in list(request.session.keys()):
      if not key.startswith("_"): # skip keys set by the django system
         del request.session[key]

    form = myForm()
    return render(request, 'login.html', {'form': form})

#######################
#def mainpage(request):
 # template = loader.get_template('mainpage.html')
  #return HttpResponse(template.render())

#######################  
def search2(request):
  search_input = "صفر"
  with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM members_member where lastname like %s", ['%' + search_input + '%'])
        rows = cursor.fetchall()
      
  #return JsonResponse({'data': rows})
  return render(request, 'showDBList.html', {'rows':rows})

#######################
def check_login1(request):
  if request.method == 'GET':
    message = "ok"
    return JsonResponse({'message': message})
  
  
#######################
@csrf_exempt
def check_login(request):
    request.session['protect_token_value'] = ""
    if request.method == 'POST':    
        #form = AuthenticationForm(request, data=request.POST)
        username = request.POST['uname']
        userpass = request.POST['upass']
        if username == "":
          #data = {'message': "u1no"}  
          data = {'message': "نام کاربری را وارد کنید"}
          return JsonResponse(data)  
        elif userpass == "":
          data = {'message': "کلمه عبور را وارد کنید"}  
          return JsonResponse(data)  


      # with connection.cursor() as cursor:
      #   cursor.execute("SELECT id FROM auth_user where username = %s and password = %s", [username, userpass])
      #   row = cursor.fetchall()

      #  if row:  #check babate query meghdary ra return bede
      #   if row[0] != "": # value id ro dare check mekone
      #     data = {'message': "ok"} 
      #    else: data = {'message': "نام کاربری یا کلمه عبور اشتباه است"}      
      # else:
      #   data = {'message': "نام کاربری یا کلمه عبور اشتباه است"  }  
      # ساخت session
        user_valid = authenticate(username=username, password=userpass)
        if user_valid is not None:
            request.session['protect_token_value'] = "myappEncript@#$2024"
            request.session['user_token_name'] = username
            d =  jdatetime.fromgregorian(date=datetime.now())
            shamsidate = str(d.year) + '/' + str(d.month) + '/' + str(d.day)
            request.session['persian_today'] = shamsidate

            sql = """ SELECT au.id, uf.gender, au.first_name 
                    from  auth_user au
                    inner join members_user_profile uf on  uf.user_id = au.id
                    where au.username = %s """
            queryset = User.objects.raw(sql, [username])
            for item in queryset:
              request.session['gender_value'] = item.gender
              if item.gender == "مرد":
                 request.session['sance_value'] = "آقایان"
              else:
                 request.session['sance_value'] = "بانوان"

              request.session['firstname_value'] = item.first_name
              request.session['lastname_value'] = item.last_name

            data = {'message': "ok"}   
            #return redirect('indexpage')
        else:            
            data = {'message': "نام کاربری یا کلمه عبور اشتباه است"}  
            request.session['protect_token_value'] = "" 
            request.session['user_token_name'] = ""
            request.session['gender_value'] = ""
            request.session['firstname_value'] = ""
            request.session['lastname_value'] = ""
    else:
        #form = AuthenticationForm()
        pass

    return JsonResponse(data)  

#####################################
from captcha.models import CaptchaStore
from captcha.helpers import captcha_image_url

#@csrf_exempt   #decrator function , auto call by django
def refresh_captcha(request):
   new_key = CaptchaStore.generate_key()
   new_image_url =  captcha_image_url(new_key)
   return JsonResponse({'key':new_key, 'image':new_image_url})

#####################################

@csrf_exempt   #decrator function , auto call by django
def register_user(request):
    if request.method == 'POST':
        form=myForm(request.POST)
        if form.is_valid():
            #uname=request.POST.get('username')
            # data = {'message': "valid " + uname, 'myresult':"success"}
            #return JsonResponse(data) 
                
            username = request.POST.get('username')
            password1 = request.POST.get('upass1')
            password2 = request.POST.get('upass2')
            email = request.POST.get('email')
            gender = request.POST.get('gender') 
            first_name = request.POST.get('fname')
            last_name = request.POST.get('lname')
            mobileno = request.POST.get('mobileno')

            if username == "":
              data = {'message': "نام کاربری را وارد کنید", 'myresult':"fail"}
              return JsonResponse(data)  
            elif email == "":
              data = {'message': "ایمیل را وارد کنید" , 'myresult':"fail"}  
              return JsonResponse(data)
            elif password1 == "":
              data = {'message': "کلمه عبور را وارد کنید" , 'myresult':"fail"}  
              return JsonResponse(data) 
            elif password2 == "":
              data = {'message': "تکرار کلمه عبور را وارد کنید" , 'myresult':"fail"}  
              return JsonResponse(data)
            elif first_name == "":
              data = {'message': "نام ورزشکار را وارد کنید" , 'myresult':"fail"}  
              return JsonResponse(data)
            elif last_name == "":
              data = {'message': "نام خانوادگی را وارد کنید" , 'myresult':"fail"}  
              return JsonResponse(data)
            elif mobileno == "":
              data = {'message': "  شماره موبایل را وارد کنید" , 'myresult':"fail"}  
              return JsonResponse(data)
            elif gender == "":
              data = {'message': "جنسیت را مشخص کنید" , 'myresult':"fail"}  
              return JsonResponse(data)
            
            # 1=admin, 2=admin2, 3=karmand, 4=user
            is_staff = "4"
            is_active = "1"
            date_joined = timezone.now()
            gender = request.POST.get('gender')  
            birthdate = request.POST.get('birthyear') 
            mobileno = request.POST.get('mobileno') 
            
            if username != "" and len(username) != 10:
              return JsonResponse({'message': 'کد ملی باید 10 رقمی باشد', 'myresult':"fail"})

            if(password1 != password2):
              return JsonResponse({'message': 'کلمات عبور یکسان نیستند', 'myresult':"fail"})
            
            if birthdate != "" and len(birthdate) != 4:
              return JsonResponse({'message': 'سال تولد باید 4 رقمی باشد', 'myresult':"fail"})
            
            if mobileno != "" and len(mobileno) != 11:
              return JsonResponse({'message': 'شماره موبایل باید 11 رقمی باشد', 'myresult':"fail"})
            
            #tabdil miladi be shamsi
            #d =  jdatetime.fromgregorian(date=date_joined)
            #shamsi = str(d.year) + '/' + str(d.month) + '/' + str(d.day)
            # tabdil shamsi be miladi
            #shamsi_date = jdatetime(d.year,d.month,d.day)
            #miladi = shamsi_date.togregorian()

            #return JsonResponse({'message': mobileno})

            # بررسی وجود کاربر با این نام کاربری
            if User.objects.filter(username=username).exists():  
              return JsonResponse({'message': 'این نام کاربری وجود دارد.', 'myresult':"fail"})    
            
            # ساخت کاربر جدید
            newuser = User.objects.create_user(username=username,email=email,password=password1,
                                              first_name=first_name,last_name=last_name)
            
            sql = """SELECT id 
                    FROM auth_user
                    where username = %s """
            queryset = sportclass.objects.raw(sql, [username])
            for item in queryset:
              field_id_value = item.id

            with connection.cursor() as cursor:
              sql = "insert into members_user_profile (birthdate, mobileno, gender, user_id) values(%s, %s, %s, %s)"
              cursor.execute(sql, [birthdate, mobileno, gender, field_id_value])
            
              # sql = "insert into members_employee (emp_name, emp_pass, fname, lname, mobileno, emp_access, gender) values(%s, %s, %s, %s, %s, %s, %s) "
              # cursor.execute(sql, [username, password1, first_name, last_name, mobileno, username, gender])
              #return JsonResponse({'message': sql})

            return JsonResponse({'message': 'ثبت نام با موفقیت انجام شد.', 'myresult':"OK"})
        else:
            #username = request.POST.get('username')
            data = {'message': 'کد امنیتی صحیح نیست', 'myresult':"captchafail"}
            return JsonResponse(data) 
      
    else:        
        return JsonResponse({'message': 'از متد POST استفاده کنید.', 'myresult':"fail"})

#####################################
#@login_required
@csrf_exempt   #decrator function , auto call by django
def indexpage(request):
   token_protect = request.session.get('protect_token_value', None)
   if token_protect == "myappEncript@#$2024":
      return render(request, 'indexpage.html')
   else:
      return render(request, 'protected_template.html')

#@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
   pass
    #if created:
       #return JsonResponse({'message': instance.birthdate})
        #members.user_profile.objects.create(
        #user=instance, 
        #birthdate=instance.birthdate, 
        #mobileno=instance.mobileno,
        #gender=instance.gender)

#@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    pass
    #instance.members.user_profile.save()

from .models import sportclass  # وارد کردن مدل sportclass
def coach_class(request):
    active_classes = sportclass.objects.filter(activeclass=1)  # بازیابی رکوردهایی که فیلد active آنها برابر با ۱ باشد
    return render(request, 'coachclass.html', {'active_classes': active_classes})

##############################################
def coach_detailclass(request):
    sql = """select  ROW_NUMBER() OVER(ORDER BY sportid) AS radif, id, coachclassid, sexsession, sportgroupname, 
        classname, cachname, freetime, countsession, format(totalclassprice, 'N0') as totalclassprice
        FROM members_coachclass
        where classname not like %s  
        order by sportid """
    #queryset = sportclass.objects.raw(sql, ['1'])
    queryset = sportclass.objects.raw(sql, ['%کنسل%'])
    return render(request, 'coachclassdetail.html', {'queryset': queryset})

##############################################
def pool_time_class(request):
    if request.session['gender_value'] == "مرد":
      sance = 1 # "آقایان"
    else:
      sance = 2 # "بانوان"

    sql = """SELECT id, fromtime, totime, price, sportdescipt, fromtimedescript, totimedescript  
              FROM members_sanceclass
              where sexkindid = %s and sportid = 1
              order by fromtime """
    
    queryset = sanceclass.objects.raw(sql, [sance])
    return render(request, 'poolshowtimes.html', {'queryset': queryset})
###############################################
@csrf_exempt   #decrator function , auto call by django
def pool_timeclass_show(request):
    if request.method == 'POST':  
      timeid = request.POST.get('timeid')
      print("timeid: " + timeid)
      
      request.session['sportertimeidchoice'] = timeid
      
      return JsonResponse({'message': 'ok'})
    else:
       return JsonResponse({'message': 'fail'})


###############################################
def bodybuiling_time_class(request):
    if request.session['gender_value'] == "مرد":
      sance = 1 # "آقایان"
    else:
      sance = 2 # "بانوان"

    sql = """SELECT id, fromtime, totime, price, sportdescipt, fromtimedescript, totimedescript  
              FROM members_sanceclass
              where sexkindid = %s and sportid = 2
              order by fromtime """
    
    queryset = sanceclass.objects.raw(sql, [sance])
    return render(request, 'bodybuilingshowtimes.html', {'queryset': queryset})

###############################################
@csrf_exempt   #decrator function , auto call by django
def bodybuiling_timeclass_show(request):
    if request.method == 'POST':  
      timeid = request.POST.get('timeid')
      print("timeid: " + timeid)
      
      request.session['sportertimeidchoice'] = timeid
      
      return JsonResponse({'message': 'ok'})
    else:
       return JsonResponse({'message': 'fail'})
    
###############################################
@csrf_exempt   #decrator function , auto call by django
def sporter_choicer_class(request):
    if request.method == 'POST':  
      classid = request.POST.get('classid')
      print("classid: " + classid)
      
      request.session['sporterclassidchoice'] = classid
      
      return JsonResponse({'message': 'ok'})
    else:
       return JsonResponse({'message': 'fail'})

###############################################
@csrf_exempt   #decrator function , auto call by django
def sporter_choicer_class_info(request):
    sporterclassidchoice = request.session.get('sporterclassidchoice')
    print("sporterclassidchoice: " + sporterclassidchoice)
    sql = """ select id, coachclassid, sexsession, classname, sportgroupname, 
          cachname, freetime, countsession, format(totalclassprice, 'N0') as totalclassprice
          FROM members_coachclass
          where coachclassid  = %s 
           """
    sporterclassidchoice = coachclass.objects.raw(sql, [sporterclassidchoice])
   
    return render(request, 'sporterchoiceclassinfo.html', {'sporterclassidchoice': sporterclassidchoice})
###############################################
@csrf_exempt   #decrator function , auto call by django
def showclassesincards(request):
    #return render(request, 'login.html')
    if request.method == 'POST':  
      sport = request.POST.get('sport')
      print("sport:: " + sport)
      
      request.session['sportclasschoice'] = sport
      
      return JsonResponse({'message': 'ok'})
    else:
       return JsonResponse({'message': 'fail'})

####################################################
@csrf_exempt   #decrator function , auto call by django
def showinfoclassesincards(request): 
    if request.session['gender_value'] == "مرد":
      sance = 1 # "آقایان"
    else:
      sance = 2 # "بانوان"

    sportclasschoice = request.session.get('sportclasschoice')
    print("sport: " + sportclasschoice)
    sql = """ select id, coachclassid, sexsession, classname, sportgroupname, 
          cachname, freetime, countsession, format(totalclassprice, 'N0') as totalclassprice
          FROM members_coachclass
          where sportgroupname  = %s and sexkindid = %s and classname not like %s
          order by classname """
    sportclassqueryset = coachclass.objects.raw(sql, [sportclasschoice, sance, '%کنسل%'])
   
    return render(request, 'sporterchoiceclass.html', {'sportclassqueryset': sportclassqueryset})
###############################################
@csrf_exempt   #decrator function , auto call by django
def showsports(request):
    #return render(request, 'login.html')
    if request.session['gender_value'] == "مرد":
       sance = 1 # "آقایان"
    else:
       sance = 2 # "بانوان"
    
    #distinct_sportgroupname = coachclass.objects.values('sportgroupname').distinct()
    distinct_sportgroupname = coachclass.objects.filter(sexkindid=sance).values('sportgroupname').distinct()
    return render(request, 'sporterchoicesport.html', {'distinct_sportgroupname': distinct_sportgroupname})
##############################################
@csrf_exempt   #decrator function , auto call by django
def bodybuildingpagecall(request):
    #if request.session['gender_value'] == "مرد":
       #sance = 1 # "آقایان"
    #else:
       #sance = 2 # "بانوان"
    
    timeid = request.session['sportertimeidchoice']

    #sportclasschoice = request.session.get('sportclasschoice')
    print("timeid: " + timeid)
    sql = """ SELECT id, fromtime, totime, price, sportdescipt 
              FROM members_sanceclass
              where id = %s 
              order by fromtime """
    queryset = sanceclass.objects.raw(sql, [timeid])
   
    return render(request, 'bodybuildingpage.html', {'queryset': queryset})

##############################################
@csrf_exempt   #decrator function , auto call by django
def poolpagecall(request):
    timeid = request.session['sportertimeidchoice']

    #sportclasschoice = request.session.get('sportclasschoice')
    print("timeid: " + timeid)
    sql = """ SELECT id, fromtime, totime, price, sportdescipt 
              FROM members_sanceclass
              where id = %s 
             """
    queryset = sanceclass.objects.raw(sql, [timeid])
   
    return render(request, 'poolpage.html', {'queryset': queryset})

##############################################
@csrf_exempt   #decrator function , auto call by django
def sporterordersave(request):
   if request.method == 'POST':
      class_id = request.POST.get('class_id', None)
      if class_id:
        try:
            coach_class_recive = coachclass.objects.get(coachclassid=class_id)
       
            shamsidate =  request.session.get('persian_today')
            #print(shamsidate)
            # Get the current time in UTC
            current_time_utc = timezone.now()  
            # Convert the current time to the Persian timezone
            persian_timezone = pytz.timezone('Asia/Tehran')
            current_time_persian = current_time_utc.astimezone(persian_timezone)
            #print(current_time_persian)

            #print(request.session.get('user_token_name'))
            #print(request.session.get('firstname_value'))
            #print(request.session.get('lastname_value'))
            #print(coach_class_recive.totalclassprice)

            # ezafe kardane etelaate daryafti class be order
            neworder = sporterorder(
              coachclassid=coach_class_recive.coachclassid, 
              sexsession=coach_class_recive.sexsession,
              sportgroupname=coach_class_recive.sportgroupname,
              classname=coach_class_recive.classname,
              cachname=coach_class_recive.cachname,
              freetime=coach_class_recive.freetime,
              countsession=coach_class_recive.countsession,
              sessionprice=coach_class_recive.sessionprice,
              totalclassprice=coach_class_recive.totalclassprice,
              createdateprice=coach_class_recive.createdateprice,
              classcreatedate=coach_class_recive.classcreatedate,
              coachid=coach_class_recive.coachid,
              sportid=coach_class_recive.sportid,
              sportgroupid=coach_class_recive.sportgroupid,
              sexkindid=coach_class_recive.sexkindid,
              melicode = request.session.get('user_token_name'),
              sporterfirstname = request.session.get('firstname_value'),
              sporterlastname = request.session.get('lastname_value'),
              sporterbankname = 'aa',
              companybankname= 'bb',
              sportercardno= 'cc',
              sporterhesabno= 'bb',
              sporterpaidprice= coach_class_recive.totalclassprice,
              sporterpaiddate = shamsidate,
              sporterpaidtime = current_time_persian,
              sportermarjano = 'gg',
              sporterrahgirino = 'hh',

            )
        
            neworder.save()
            return HttpResponse(True)
        except coachclass.DoesNotExist:
            return HttpResponse(False)
      
   
##############################################
@csrf_exempt   #decrator function , auto call by django
def sporterordershow(request):
    sporterclassidchoice = request.session.get('sporterclassidchoice')
    username = request.session.get('user_token_name')
    print("sporterclassidchoice: " + sporterclassidchoice)
    sql = """ select id, coachclassid, sexsession, classname, sportgroupname, 
          cachname, freetime, countsession, format(totalclassprice, 'N0') as totalclassprice,
          sporterpaidprice, sporterpaiddate, sporterpaidtime, sportermarjano, sporterrahgirino
          FROM members_sporterorder
          where coachclassid  = %s and melicode = %s
          order by id desc
          limit 1
           """
    sporterclassidchoice = sporterorder.objects.raw(sql, [sporterclassidchoice, username])
   
    return render(request, 'sporterordershow.html', {'sporterclassidchoice': sporterclassidchoice})
##############################################
def coachclass_givedata(request):
   return render(request, 'givecochclassdata.html')
##############################################

from django.db import connection
def give_coachclassdata_fromexcelfile(request):
    #table1
    # خواندن فایل اکسل
    df = pd.read_excel('coachclasses.xlsx')
    #coachclass.objects.all().delete()
    cursor = connection.cursor()
    cursor.execute("TRUNCATE TABLE members_coachclass")

    # coachclass = pd.DataFrame(columns=['id', 'coachclassid', 'sexsession', 'sportgroupname', 'sportgroupname', 'classname', 'freetime', 'countsession', 'sessionprice', 'totalclassprice', 'createdateprice', 'classcreatedate', 'coachid', 'sportid', 'sportgroupid', 'sexkindid'])

    # ذخیره داده‌ها در پایگاه داده
    data = df.to_dict(orient='records')
    for record in data:
       coachclass.objects.create(**record)

    # messages.success(request, 'اطلاعات با موفقیت به جدول اضافه شدند')

    return render(request, 'givecochclassdata.html')

##############################################

def give_coachclasstimedata_fromexcelfile(request):
    #table 2
     # خواندن فایل اکسل
    df = pd.read_excel('coachclasses_times.xlsx')
    #coachclasstimes.objects.all().delete()
    cursor = connection.cursor()
    cursor.execute("TRUNCATE TABLE members_coachclasstimes")

    # coachclass = pd.DataFrame(columns=['id', 'coachclassid',
    # ذخیره داده‌ها در پایگاه داده
    data = df.to_dict(orient='records')
    for record in data:
       coachclasstimes.objects.create(**record)

    return render(request, 'givecochclassdata.html')

#############################################  
def coachclassdetails(request): #, classid):  
    if request.method == 'GET':
      classid = request.GET.get('class_id')
      sql = """SELECT cct.id, cc.classname, cct.salonname, cct.dayname ,cct.clocksport
        FROM members_coachclasstimes cct
        inner join members_coachclass cc on cc.coachclassid = cct.coachclassid
        where cc.coachclassid = %s """
      #queryset = sportclass.objects.raw(sql, ['1'])
      queryset = sportclass.objects.raw(sql, [classid])
      return render(request, 'coachclassdetailinfo.html', {'secondqueryset': queryset})
    
  
#############################################  
def coachclass_tobasket(request, classid):  
   
   return  

