from django import forms
from captcha.fields import CaptchaField
    
class myForm(forms.Form):
    #mycaptcha = CaptchaField(widget=forms.TextInput(attrs={'style': 'width: 200px;'}), label='کد امنیتی ')
    captcha = CaptchaField(label='کد امنیتی ')
    
    